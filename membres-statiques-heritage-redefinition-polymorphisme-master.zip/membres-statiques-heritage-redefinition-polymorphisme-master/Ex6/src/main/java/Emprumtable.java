interface Empruntable {
    void emprunter();
    void retourner();
}
